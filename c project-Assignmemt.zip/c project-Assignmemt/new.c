#include <stdio.h>
int main(){
int i;
char *name[20];


for (i<0;i<10;i++){
  printf("Enter your name: ");
  scanf("%s",&name);
}
printf("congratulations!,you have successfully printed ten names/n");
printf("The names are: %s",name);

  return 0;
}
#include <stdio.h>//program to print a number from 1 to N
int main(){
  int i,n;
  printf("Enter any number:");
  scanf("%d",&n);

  printf("set of natural numbers from 1 to %d: \n",n);

  for(i=1;i<=n;i++){
    printf("%d\n",i);

  }
  return 0;
  
}
//program to write hello world
#include <stdio.h>
int main(){
    printf("hello world!");//print result 
    return 0;
} 